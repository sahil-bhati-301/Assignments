import { LightningElement, api, wire } from 'lwc';
import { getRecord, getFieldValue, updateRecord } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getContacts from '@salesforce/apex/ContactController.getContacts';
import createContact from '@salesforce/apex/ContactController.createContact';
import ID_FIELD from '@salesforce/schema/Account.Id';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import PHONE_FIELD from '@salesforce/schema/Account.Phone';
import WEBSITE_FIELD from '@salesforce/schema/Account.Website';
import CITY_FIELD from '@salesforce/schema/Account.BillingCity';
import DESCRIPTION_FIELD from '@salesforce/schema/Account.Description';

// Q1: Id + 5 other fields
const COLUMNS = [
    { label: 'Contact Id', fieldName: 'Id', type: 'text', initialWidth: 180 },
    { label: 'Name', fieldName: 'Name', type: 'text' },
    { label: 'Title', fieldName: 'Title', type: 'text' },
    { label: 'Email', fieldName: 'Email', type: 'email' },
    { label: 'Phone', fieldName: 'Phone', type: 'phone' },
    { label: 'Department', fieldName: 'Department', type: 'text' }
];

const ACCOUNT_FIELDS = [NAME_FIELD, PHONE_FIELD, WEBSITE_FIELD, CITY_FIELD, DESCRIPTION_FIELD];
const EMPTY_CONTACT = { FirstName: '', LastName: '', Email: '', Phone: '', Title: '' };
const EMPTY_ACCOUNT = { Name: '', Phone: '', Website: '', BillingCity: '', Description: '' };

/** Turns Apex / LDS / JS errors into a single readable string. */
function errorText(error) {
    const messages = [];
    const body = error && error.body;
    if (Array.isArray(body)) {
        body.forEach((e) => messages.push(e.message));
    } else if (body) {
        if (typeof body.message === 'string') {
            messages.push(body.message);
        }
        const output = body.output; // LDS write errors carry the detail here
        if (output) {
            (output.errors || []).forEach((e) => messages.push(e.message));
            Object.values(output.fieldErrors || {}).forEach((list) => list.forEach((e) => messages.push(e.message)));
        }
    }
    if (!messages.length && error && typeof error.message === 'string') {
        messages.push(error.message);
    }
    return messages.filter(Boolean).join(' ') || 'Unknown error';
}

export default class AccountContactManager extends LightningElement {
    /** Set automatically when the component sits on an Account record page. */
    @api recordId;

    columns = COLUMNS;

    // account chosen with the picker (only used when there is no recordId)
    pickedAccountId;

    // Q2: text in the box vs. the term actually applied to the query
    searchInput = '';
    appliedSearchTerm = '';

    contacts = [];
    errorMessage;
    wiredContactsResult;

    // Q3: create-contact modal
    showCreateModal = false;
    newContact = { ...EMPTY_CONTACT };
    isCreating = false;
    createError;

    // Q3: update-account modal
    showUpdateModal = false;
    accountForm = { ...EMPTY_ACCOUNT };
    isUpdating = false;
    updateError;

    focusPending = false;

    // ---------- account context ----------
    get selectedAccountId() {
        return this.recordId || this.pickedAccountId;
    }
    get hasAccount() {
        return Boolean(this.selectedAccountId);
    }
    get noAccount() {
        return !this.hasAccount;
    }
    get showPicker() {
        return !this.recordId;
    }

    // Lightning Data Service: gives the card title and pre-fills the update modal,
    // and refreshes by itself after updateRecord succeeds.
    @wire(getRecord, { recordId: '$selectedAccountId', fields: ACCOUNT_FIELDS })
    account;

    get accountRecord() {
        return this.account && this.account.data ? this.account.data : undefined;
    }
    get accountName() {
        return this.accountRecord ? getFieldValue(this.accountRecord, NAME_FIELD) : undefined;
    }
    get cardTitle() {
        return this.accountName ? `Contacts for ${this.accountName}` : 'Contacts';
    }
    get updateDisabled() {
        return this.noAccount || !this.accountRecord;
    }

    // ---------- Q1 + Q2: wired contacts (reactive to account and applied search term) ----------
    @wire(getContacts, { accountId: '$selectedAccountId', searchTerm: '$appliedSearchTerm' })
    wiredContacts(result) {
        this.wiredContactsResult = result;
        const { data, error } = result;
        if (data) {
            this.contacts = data;
            this.errorMessage = undefined;
        } else if (error) {
            this.contacts = [];
            this.errorMessage = errorText(error);
        }
    }

    get isLoading() {
        return this.hasAccount && !this.wiredContactsResult;
    }
    get hasContacts() {
        return this.contacts.length > 0;
    }
    get hasSearch() {
        return Boolean(this.appliedSearchTerm);
    }
    get showEmptyState() {
        return this.hasAccount && !this.isLoading && !this.errorMessage && !this.hasContacts;
    }
    get showFooter() {
        return this.hasAccount && !this.isLoading && !this.errorMessage;
    }
    get emptyTitle() {
        return this.hasSearch ? 'No matching contacts' : 'No contacts yet';
    }
    get emptyBody() {
        return this.hasSearch
            ? `No contact name contains “${this.appliedSearchTerm}”. Try a different name or reset the search.`
            : 'This account has no contacts. Use Create Contact to add the first one.';
    }
    get footerLabel() {
        const count = this.contacts.length;
        const noun = count === 1 ? 'contact' : 'contacts';
        return this.hasSearch ? `${count} ${noun} matching “${this.appliedSearchTerm}”` : `${count} ${noun}`;
    }

    // ---------- account picker (app / home pages) ----------
    handleAccountPick(event) {
        this.pickedAccountId = event.detail.recordId || undefined;
        this.searchInput = '';
        this.appliedSearchTerm = '';
        this.contacts = [];
        this.errorMessage = undefined;
        this.wiredContactsResult = undefined;
    }

    // ---------- Q2: search ----------
    handleSearchInputChange(event) {
        this.searchInput = event.target.value;
    }
    handleSearchKeyUp(event) {
        if (event.key === 'Enter') {
            this.handleSearch();
        }
    }
    handleSearch() {
        const term = (this.searchInput || '').trim();
        if (term === this.appliedSearchTerm) {
            this.refreshContacts(); // same term: just re-query
        } else {
            this.appliedSearchTerm = term; // wire re-runs automatically
        }
    }
    handleResetSearch() {
        this.searchInput = '';
        if (this.appliedSearchTerm) {
            this.appliedSearchTerm = '';
        }
    }

    async refreshContacts() {
        if (!this.wiredContactsResult) {
            return;
        }
        try {
            await refreshApex(this.wiredContactsResult);
        } catch (error) {
            this.errorMessage = errorText(error);
        }
    }

    // ---------- shared modal helpers ----------
    renderedCallback() {
        if (this.focusPending) {
            const target = this.template.querySelector('lightning-input[data-autofocus]');
            if (target) {
                target.focus();
                this.focusPending = false;
            }
        }
    }

    handleModalKeyDown(event) {
        if (event.key === 'Escape') {
            this.handleCloseCreate();
            this.handleCloseUpdate();
        }
    }

    validateInputs(selector) {
        // report on every input so all errors show, not just the first
        return [...this.template.querySelectorAll(selector)].reduce((valid, input) => {
            const inputValid = input.reportValidity();
            return valid && inputValid;
        }, true);
    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }

    // ---------- Q3: Create Contact (imperative Apex) ----------
    handleOpenCreate() {
        this.newContact = { ...EMPTY_CONTACT };
        this.createError = undefined;
        this.showCreateModal = true;
        this.focusPending = true;
    }
    handleCloseCreate() {
        if (!this.isCreating) {
            this.showCreateModal = false;
        }
    }
    handleContactChange(event) {
        const { field } = event.target.dataset;
        this.newContact = { ...this.newContact, [field]: event.target.value };
    }
    async handleSaveContact() {
        if (!this.validateInputs('.create-modal lightning-input')) {
            return;
        }
        this.isCreating = true;
        this.createError = undefined;
        try {
            await createContact({ newContact: { ...this.newContact, AccountId: this.selectedAccountId } });
            const fullName = `${this.newContact.FirstName} ${this.newContact.LastName}`.trim();
            this.showToast('Contact created', `${fullName} was added to the account.`, 'success');
            this.showCreateModal = false;
            await this.refreshContacts(); // new Contact appears in the table
        } catch (error) {
            this.createError = errorText(error);
        } finally {
            this.isCreating = false;
        }
    }

    // ---------- Q3: Update Account (Lightning Data Service updateRecord) ----------
    handleOpenUpdate() {
        const rec = this.accountRecord;
        if (!rec) {
            return;
        }
        this.accountForm = {
            Name: getFieldValue(rec, NAME_FIELD) ?? '',
            Phone: getFieldValue(rec, PHONE_FIELD) ?? '',
            Website: getFieldValue(rec, WEBSITE_FIELD) ?? '',
            BillingCity: getFieldValue(rec, CITY_FIELD) ?? '',
            Description: getFieldValue(rec, DESCRIPTION_FIELD) ?? ''
        };
        this.updateError = undefined;
        this.showUpdateModal = true;
        this.focusPending = true;
    }
    handleCloseUpdate() {
        if (!this.isUpdating) {
            this.showUpdateModal = false;
        }
    }
    handleAccountChange(event) {
        const { field } = event.target.dataset;
        this.accountForm = { ...this.accountForm, [field]: event.target.value };
    }
    async handleSaveAccount() {
        if (!this.validateInputs('.update-modal lightning-input, .update-modal lightning-textarea')) {
            return;
        }
        this.isUpdating = true;
        this.updateError = undefined;

        const name = this.accountForm.Name.trim();
        const fields = {
            [ID_FIELD.fieldApiName]: this.selectedAccountId,
            [NAME_FIELD.fieldApiName]: name,
            [PHONE_FIELD.fieldApiName]: this.accountForm.Phone || null,
            [WEBSITE_FIELD.fieldApiName]: this.accountForm.Website || null,
            [CITY_FIELD.fieldApiName]: this.accountForm.BillingCity || null,
            [DESCRIPTION_FIELD.fieldApiName]: this.accountForm.Description || null
        };

        try {
            await updateRecord({ fields });
            this.showToast('Account updated', `${name} was saved.`, 'success');
            this.showUpdateModal = false; // card title updates automatically via LDS
        } catch (error) {
            this.updateError = errorText(error);
        } finally {
            this.isUpdating = false;
        }
    }
}
