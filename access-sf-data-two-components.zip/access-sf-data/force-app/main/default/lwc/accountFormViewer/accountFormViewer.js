import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import ACCOUNT_OBJECT from '@salesforce/schema/Account';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import ACCOUNT_NUMBER_FIELD from '@salesforce/schema/Account.AccountNumber';
import PHONE_FIELD from '@salesforce/schema/Account.Phone';
import WEBSITE_FIELD from '@salesforce/schema/Account.Website';
import INDUSTRY_FIELD from '@salesforce/schema/Account.Industry';
import TYPE_FIELD from '@salesforce/schema/Account.Type';
import RATING_FIELD from '@salesforce/schema/Account.Rating';
import REVENUE_FIELD from '@salesforce/schema/Account.AnnualRevenue';
import EMPLOYEES_FIELD from '@salesforce/schema/Account.NumberOfEmployees';
import BILLING_CITY_FIELD from '@salesforce/schema/Account.BillingCity';
import BILLING_STREET_FIELD from '@salesforce/schema/Account.BillingStreet';
import BILLING_STATE_FIELD from '@salesforce/schema/Account.BillingState';
import BILLING_POSTAL_FIELD from '@salesforce/schema/Account.BillingPostalCode';
import BILLING_COUNTRY_FIELD from '@salesforce/schema/Account.BillingCountry';

// Q6: fields that must be filled in before the edit form can be saved
const REQUIRED_FIELDS = [
    { field: NAME_FIELD, label: 'Account Name' },
    { field: PHONE_FIELD, label: 'Phone' },
    { field: WEBSITE_FIELD, label: 'Website' },
    { field: BILLING_STREET_FIELD, label: 'Billing Street' },
    { field: BILLING_CITY_FIELD, label: 'Billing City' },
    { field: BILLING_COUNTRY_FIELD, label: 'Billing Country' }
];

export default class AccountFormViewer extends LightningElement {
    /** Set automatically when the component sits on an Account record page. */
    @api recordId;

    pickedAccountId;
    isSaving = false;
    validationMessage;

    accountObject = ACCOUNT_OBJECT;

    // Q4: Account Name, Account Number, Phone, Website + 6 more = 10 fields
    viewFields = [
        NAME_FIELD,
        ACCOUNT_NUMBER_FIELD,
        PHONE_FIELD,
        WEBSITE_FIELD,
        INDUSTRY_FIELD,
        TYPE_FIELD,
        RATING_FIELD,
        REVENUE_FIELD,
        EMPLOYEES_FIELD,
        BILLING_CITY_FIELD
    ];

    // Q6: fields for the edit form
    nameField = NAME_FIELD;
    phoneField = PHONE_FIELD;
    websiteField = WEBSITE_FIELD;
    streetField = BILLING_STREET_FIELD;
    cityField = BILLING_CITY_FIELD;
    stateField = BILLING_STATE_FIELD;
    postalField = BILLING_POSTAL_FIELD;
    countryField = BILLING_COUNTRY_FIELD;

    // ---------- account context ----------
    get selectedAccountId() {
        return this.recordId || this.pickedAccountId;
    }
    get hasAccount() {
        return Boolean(this.selectedAccountId);
    }
    get showPicker() {
        return !this.recordId;
    }

    handleAccountPick(event) {
        this.pickedAccountId = event.detail.recordId || undefined;
        this.validationMessage = undefined;
    }

    // ---------- Q4: view mode ----------
    handleViewSuccess() {
        this.showToast('Account saved', 'Your changes were saved.', 'success');
    }

    // ---------- Q6: edit form with validation ----------
    handleSubmit(event) {
        const fields = event.detail.fields;
        const missing = REQUIRED_FIELDS.filter(({ field }) => !this.hasValue(fields[field.fieldApiName]));

        if (missing.length) {
            event.preventDefault(); // stop the save
            this.validationMessage = `Complete the required fields before saving: ${missing
                .map(({ label }) => label)
                .join(', ')}.`;
            return;
        }
        this.validationMessage = undefined;
        this.isSaving = true;
    }

    handleEditSuccess() {
        this.isSaving = false;
        this.validationMessage = undefined;
        // View and Read only tabs use the same record cache, so they update by themselves.
        this.showToast('Account saved', 'The account was updated.', 'success');
    }

    handleEditError() {
        this.isSaving = false; // lightning-messages displays the server error
    }

    handleReset() {
        this.validationMessage = undefined;
        this.template.querySelectorAll('lightning-input-field').forEach((field) => field.reset());
    }

    hasValue(value) {
        return value !== null && value !== undefined && String(value).trim() !== '';
    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}
