# Access SF Data – LWC assignment

Two Lightning Web Components, styled with base `lightning-*` components and SLDS utility classes so they match the org's theme.

| Question | Component | What it shows |
|---|---|---|
| Q1 | `accountContactManager` | Contacts of the Account in a `lightning-datatable` (Id, Name, Title, Email, Phone, Department) via `@wire` |
| Q2 | `accountContactManager` | Name search box + **Search Contacts** button; the wire re-runs with the applied term |
| Q3 | `accountContactManager` | **Create Contact** popup (imperative Apex) and **Update Account** popup (LDS `updateRecord`) |
| Q4 | `accountFormViewer` → *View* tab | `lightning-record-form mode="view"`, 10 fields |
| Q5 | `accountFormViewer` → *Read only* tab | `lightning-record-form mode="readonly"`, full page layout |
| Q6 | `accountFormViewer` → *Edit* tab | `lightning-record-edit-form` with required-field validation |

Not a component, but required: `ContactController` (Apex, used for the contact search and the imperative create call) and its test class.

## Deploy

```bash
sf org login web --alias myorg
sf project deploy start --source-dir force-app --target-org myorg
sf apex run test --class-names ContactControllerTest --result-format human --target-org myorg
```

## Use

1. Open an Account record → gear icon → **Edit Page**.
2. Drag **Account Contact Manager** and **Account Form Viewer** onto the page → Save → Activate.
3. Both also work on an App/Home page: an account picker appears when there is no record context.
