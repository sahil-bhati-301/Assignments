# Access SF Data – LWC assignment

SLDS-styled Lightning Web Components (base `lightning-*` components + SLDS utility classes, so they match the org's theme).

| Question | Where | What it shows |
|---|---|---|
| Q1 | `accountContactManager` | Contacts of the Account in a `lightning-datatable` (Id, Name, Title, Email, Phone, Department) via `@wire` |
| Q2 | `accountContactManager` | Name search box + **Search Contacts** button; wire re-runs with the applied term |
| Q3 | `accountContactManager` → `contactCreateModal`, `accountUpdateModal` | **Create Contact** (imperative Apex) and **Update Account** (LDS `updateRecord`) popups |
| Q4 | `accountFormViewer` → *View* tab | `lightning-record-form mode="view"`, 10 fields |
| Q5 | `accountFormViewer` → *Read only* tab | `lightning-record-form mode="readonly"`, full page layout |
| Q6 | `accountFormViewer` → *Edit* tab | `lightning-record-edit-form` with required-field validation |

Supporting files: `ContactController` (+ test class), `utils` (error helper).

## Deploy

```bash
sf org login web --alias myorg
sf project deploy start --source-dir force-app --target-org myorg
sf apex run test --class-names ContactControllerTest --result-format human --target-org myorg
```

## Use

1. Open an Account record → gear icon → **Edit Page**.
2. Drag **Account Contact Manager** and **Account Form Viewer** onto the page → Save → Activate.
3. Both components also work on an App/Home page: an account picker appears when there is no record context.
