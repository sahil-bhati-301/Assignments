import { LightningElement, api, wire } from 'lwc';
import { getRecord, getFieldValue, updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import ID_FIELD from '@salesforce/schema/Account.Id';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import PHONE_FIELD from '@salesforce/schema/Account.Phone';
import WEBSITE_FIELD from '@salesforce/schema/Account.Website';
import CITY_FIELD from '@salesforce/schema/Account.BillingCity';
import DESCRIPTION_FIELD from '@salesforce/schema/Account.Description';
import { reduceErrors } from 'c/utils';

const FIELDS = [NAME_FIELD, PHONE_FIELD, WEBSITE_FIELD, CITY_FIELD, DESCRIPTION_FIELD];

export default class AccountUpdateModal extends LightningElement {
    @api accountId;

    form = { Name: '', Phone: '', Website: '', BillingCity: '', Description: '' };
    isPrefilled = false;
    isSaving = false;
    errorMessage;
    hasFocused = false;

    // Q3: pre-fill the form with the account's current values (Lightning Data Service)
    @wire(getRecord, { recordId: '$accountId', fields: FIELDS })
    wiredAccount({ data, error }) {
        if (data && !this.isPrefilled) {
            this.form = {
                Name: getFieldValue(data, NAME_FIELD) ?? '',
                Phone: getFieldValue(data, PHONE_FIELD) ?? '',
                Website: getFieldValue(data, WEBSITE_FIELD) ?? '',
                BillingCity: getFieldValue(data, CITY_FIELD) ?? '',
                Description: getFieldValue(data, DESCRIPTION_FIELD) ?? ''
            };
            this.isPrefilled = true;
        } else if (error) {
            this.errorMessage = reduceErrors(error).join(' ');
        }
    }

    get isLoading() {
        return !this.isPrefilled && !this.errorMessage;
    }
    get isBusy() {
        return this.isLoading || this.isSaving;
    }

    renderedCallback() {
        if (!this.hasFocused) {
            const first = this.template.querySelector('lightning-input');
            if (first) {
                first.focus();
                this.hasFocused = true;
            }
        }
    }

    handleChange(event) {
        const { field } = event.target.dataset;
        this.form = { ...this.form, [field]: event.target.value };
    }

    handleKeyDown(event) {
        if (event.key === 'Escape' && !this.isSaving) {
            this.handleCancel();
        }
    }

    handleCancel() {
        this.dispatchEvent(new CustomEvent('closemodal'));
    }

    isFormValid() {
        return [...this.template.querySelectorAll('lightning-input, lightning-textarea')].reduce(
            (valid, input) => {
                const inputValid = input.reportValidity();
                return valid && inputValid;
            },
            true
        );
    }

    // Q3: Update Account - Lightning Data Service updateRecord
    async handleSave() {
        if (!this.isFormValid()) {
            return;
        }
        this.isSaving = true;
        this.errorMessage = undefined;

        const fields = {
            [ID_FIELD.fieldApiName]: this.accountId,
            [NAME_FIELD.fieldApiName]: this.form.Name.trim(),
            [PHONE_FIELD.fieldApiName]: this.form.Phone || null,
            [WEBSITE_FIELD.fieldApiName]: this.form.Website || null,
            [CITY_FIELD.fieldApiName]: this.form.BillingCity || null,
            [DESCRIPTION_FIELD.fieldApiName]: this.form.Description || null
        };

        try {
            await updateRecord({ fields });
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Account updated',
                    message: `${this.form.Name.trim()} was saved.`,
                    variant: 'success'
                })
            );
            this.dispatchEvent(new CustomEvent('accountupdated'));
        } catch (error) {
            this.errorMessage = reduceErrors(error).join(' ');
        } finally {
            this.isSaving = false;
        }
    }
}
