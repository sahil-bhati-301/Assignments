import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createContact from '@salesforce/apex/ContactController.createContact';
import { reduceErrors } from 'c/utils';

export default class ContactCreateModal extends LightningElement {
    @api accountId;

    contact = { FirstName: '', LastName: '', Email: '', Phone: '', Title: '' };
    isSaving = false;
    errorMessage;
    hasFocused = false;

    renderedCallback() {
        if (!this.hasFocused) {
            const first = this.template.querySelector('lightning-input');
            if (first) {
                first.focus();
                this.hasFocused = true;
            }
        }
    }

    handleChange(event) {
        const { field } = event.target.dataset;
        this.contact = { ...this.contact, [field]: event.target.value };
    }

    handleKeyDown(event) {
        if (event.key === 'Escape' && !this.isSaving) {
            this.handleCancel();
        }
    }

    handleCancel() {
        this.dispatchEvent(new CustomEvent('closemodal'));
    }

    isFormValid() {
        return [...this.template.querySelectorAll('lightning-input')].reduce((valid, input) => {
            const inputValid = input.reportValidity(); // call on every input so all errors show
            return valid && inputValid;
        }, true);
    }

    // Q3: Create Contact - imperative Apex call
    async handleSave() {
        if (!this.isFormValid()) {
            return;
        }
        this.isSaving = true;
        this.errorMessage = undefined;
        try {
            const contactId = await createContact({
                newContact: { ...this.contact, AccountId: this.accountId }
            });
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Contact created',
                    message: `${this.contact.FirstName} ${this.contact.LastName}`.trim() + ' was added to the account.',
                    variant: 'success'
                })
            );
            this.dispatchEvent(new CustomEvent('contactcreated', { detail: { contactId } }));
        } catch (error) {
            this.errorMessage = reduceErrors(error).join(' ');
        } finally {
            this.isSaving = false;
        }
    }
}
