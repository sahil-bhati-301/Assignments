import { LightningElement, api, wire } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';
import getContacts from '@salesforce/apex/ContactController.getContacts';
import ACCOUNT_NAME_FIELD from '@salesforce/schema/Account.Name';
import { reduceErrors } from 'c/utils';

// Q1: Id + 5 other fields
const COLUMNS = [
    { label: 'Contact Id', fieldName: 'Id', type: 'text', initialWidth: 180 },
    { label: 'Name', fieldName: 'Name', type: 'text' },
    { label: 'Title', fieldName: 'Title', type: 'text' },
    { label: 'Email', fieldName: 'Email', type: 'email' },
    { label: 'Phone', fieldName: 'Phone', type: 'phone' },
    { label: 'Department', fieldName: 'Department', type: 'text' }
];

export default class AccountContactManager extends LightningElement {
    /** Set automatically when the component sits on an Account record page. */
    @api recordId;

    columns = COLUMNS;

    // account chosen with the picker (only used when there is no recordId)
    pickedAccountId;

    // Q2: text in the box vs. the term actually applied to the query
    searchInput = '';
    appliedSearchTerm = '';

    contacts = [];
    errorMessage;
    wiredContactsResult;

    showCreateModal = false;
    showUpdateModal = false;

    // ---------- account context ----------
    get selectedAccountId() {
        return this.recordId || this.pickedAccountId;
    }
    get hasAccount() {
        return Boolean(this.selectedAccountId);
    }
    get noAccount() {
        return !this.hasAccount;
    }
    get showPicker() {
        return !this.recordId;
    }

    // Account name comes from Lightning Data Service, so it refreshes by itself
    // after the Update Account modal saves.
    @wire(getRecord, { recordId: '$selectedAccountId', fields: [ACCOUNT_NAME_FIELD] })
    account;

    get accountName() {
        return this.account && this.account.data
            ? getFieldValue(this.account.data, ACCOUNT_NAME_FIELD)
            : undefined;
    }
    get cardTitle() {
        return this.accountName ? `Contacts for ${this.accountName}` : 'Contacts';
    }

    // ---------- Q1 + Q2: wired contacts (reactive to account and applied search term) ----------
    @wire(getContacts, { accountId: '$selectedAccountId', searchTerm: '$appliedSearchTerm' })
    wiredContacts(result) {
        this.wiredContactsResult = result;
        const { data, error } = result;
        if (data) {
            this.contacts = data;
            this.errorMessage = undefined;
        } else if (error) {
            this.contacts = [];
            this.errorMessage = reduceErrors(error).join(' ');
        }
    }

    get isLoading() {
        return this.hasAccount && !this.wiredContactsResult;
    }
    get hasContacts() {
        return this.contacts.length > 0;
    }
    get hasSearch() {
        return Boolean(this.appliedSearchTerm);
    }
    get showEmptyState() {
        return this.hasAccount && !this.isLoading && !this.errorMessage && !this.hasContacts;
    }
    get showFooter() {
        return this.hasAccount && !this.isLoading && !this.errorMessage;
    }
    get emptyTitle() {
        return this.hasSearch ? 'No matching contacts' : 'No contacts yet';
    }
    get emptyBody() {
        return this.hasSearch
            ? `No contact name contains “${this.appliedSearchTerm}”. Try a different name or reset the search.`
            : 'This account has no contacts. Use Create Contact to add the first one.';
    }
    get footerLabel() {
        const count = this.contacts.length;
        const noun = count === 1 ? 'contact' : 'contacts';
        return this.hasSearch ? `${count} ${noun} matching “${this.appliedSearchTerm}”` : `${count} ${noun}`;
    }

    // ---------- account picker (app / home pages) ----------
    handleAccountPick(event) {
        this.pickedAccountId = event.detail.recordId || undefined;
        this.searchInput = '';
        this.appliedSearchTerm = '';
        this.contacts = [];
        this.errorMessage = undefined;
        this.wiredContactsResult = undefined;
    }

    // ---------- Q2: search ----------
    handleSearchInputChange(event) {
        this.searchInput = event.target.value;
    }
    handleSearchKeyUp(event) {
        if (event.key === 'Enter') {
            this.handleSearch();
        }
    }
    handleSearch() {
        const term = (this.searchInput || '').trim();
        if (term === this.appliedSearchTerm) {
            this.refreshContacts(); // same term: just re-query
        } else {
            this.appliedSearchTerm = term; // wire re-runs automatically
        }
    }
    handleResetSearch() {
        this.searchInput = '';
        if (this.appliedSearchTerm) {
            this.appliedSearchTerm = '';
        }
    }

    async refreshContacts() {
        if (!this.wiredContactsResult) {
            return;
        }
        try {
            await refreshApex(this.wiredContactsResult);
        } catch (error) {
            this.errorMessage = reduceErrors(error).join(' ');
        }
    }

    // ---------- Q3: modals ----------
    handleOpenCreate() {
        this.showCreateModal = true;
    }
    handleCloseCreate() {
        this.showCreateModal = false;
    }
    handleContactCreated() {
        this.showCreateModal = false;
        this.refreshContacts(); // new Contact appears in the table
    }

    handleOpenUpdate() {
        this.showUpdateModal = true;
    }
    handleCloseUpdate() {
        this.showUpdateModal = false;
    }
    handleAccountUpdated() {
        this.showUpdateModal = false; // LDS already refreshed the account name in the card title
    }
}
