/**
 * Turns Apex / LDS / JS errors into an array of readable messages.
 */
export function reduceErrors(errors) {
    if (!Array.isArray(errors)) {
        errors = [errors];
    }
    return errors
        .filter((error) => !!error)
        .map((error) => {
            if (Array.isArray(error.body)) {
                return error.body.map((e) => e.message);
            }
            if (error.body) {
                const messages = [];
                if (typeof error.body.message === 'string') {
                    messages.push(error.body.message);
                }
                const output = error.body.output; // LDS write errors carry the detail here
                if (output) {
                    (output.errors || []).forEach((e) => messages.push(e.message));
                    Object.values(output.fieldErrors || {}).forEach((list) =>
                        list.forEach((e) => messages.push(e.message))
                    );
                }
                if (messages.length) {
                    return messages;
                }
            }
            if (typeof error.message === 'string') {
                return error.message;
            }
            return error.statusText;
        })
        .reduce((prev, curr) => prev.concat(curr), [])
        .filter((message) => !!message);
}
