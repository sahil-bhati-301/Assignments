trigger OpportunityPointsTrigger on Opportunity (after insert, after update, after delete, after undelete) {

    // accounts whose points need to be recalculated
    Set<Id> accountIds = new Set<Id>();

    if (Trigger.isDelete) {
        // deleted opportunities only exist in Trigger.old
        for (Opportunity opp : Trigger.old) {
            if (opp.AccountId != null) {
                accountIds.add(opp.AccountId);
            }
        }
    } else {
        for (Opportunity opp : Trigger.new) {

            if (Trigger.isUpdate) {
                Opportunity oldOpp = Trigger.oldMap.get(opp.Id);

                // points only change if the stage or the account changed
                if (oldOpp.StageName == opp.StageName && oldOpp.AccountId == opp.AccountId) {
                    continue;
                }

                // if the opportunity moved to another account, the old account needs a recalculation too
                if (oldOpp.AccountId != null) {
                    accountIds.add(oldOpp.AccountId);
                }
            }

            if (opp.AccountId != null) {
                accountIds.add(opp.AccountId);
            }
        }
    }

    if (!accountIds.isEmpty()) {
        AccountPointsHandler.updatePoints(accountIds);
    }
}
